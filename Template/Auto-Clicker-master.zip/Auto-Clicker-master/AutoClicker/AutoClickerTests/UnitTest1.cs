﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AutoClickerTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}

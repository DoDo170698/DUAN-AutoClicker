# Auto-Clicker
An open-source, C# auto-clicker. 

This program will automatically click in an interval of random length between a lower/upper limit. 

It also has random variation of moving the mouse a couple of pixels randomly around it's current location. User has a specified min and max number of clicks before it's movement, specified by the user in the settings. 

It's original intention was as an Auto-alcher for Oldschool Runescape, with random variation built in to avoid bot detection, which is a bannable offense. 

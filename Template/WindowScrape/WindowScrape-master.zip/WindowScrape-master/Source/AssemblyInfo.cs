﻿// Assembly WindowScrape, Version 1.0.0.0

[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyCompany("DataDink")]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyProduct("WindowScrape")]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9 DataDink 2009")]
[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.DisableOptimizations | System.Diagnostics.DebuggableAttribute.DebuggingModes.EnableEditAndContinue | System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | System.Diagnostics.DebuggableAttribute.DebuggingModes.Default)]
[assembly: System.Reflection.AssemblyTitle("WindowScrape")]
[assembly: System.Reflection.AssemblyDescription("Simplifies manipulating Hwnd items.")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Runtime.InteropServices.Guid("beba9058-7a17-4079-81d8-f76f22da5260")]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]


# WindowScrape
Used in personal scripting for manipulating external applications and their windows.

# License

I'm not good at licenses, folks. Just use the software and don't sue me for anything.
